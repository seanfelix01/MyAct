function myFunction() {
    document.getElementById("demo").innerHTML = "Paragraph Changed.";
}